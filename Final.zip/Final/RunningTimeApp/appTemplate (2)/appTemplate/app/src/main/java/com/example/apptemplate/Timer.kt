package com.example.apptemplate

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.view.View
import android.widget.Button
import android.widget.TextView

class Timer : AppCompatActivity() {
    private lateinit var lapTimerText: TextView
    private lateinit var startButton: Button
    private lateinit var lapButton: Button
    private lateinit var resetButton: Button

    private var lapCount = 1
    private var isRunning = false
    private var elapsedTime = 0L
    private var lapTime = 0L

    private lateinit var handler: Handler
    private lateinit var runnable: Runnable

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_timer)
        lapTimerText = findViewById(R.id.lapTimerText)
        startButton = findViewById(R.id.startButton)
        lapButton = findViewById(R.id.intervalButton)
        resetButton = findViewById(R.id.resertButton)

        val timerReturnBtn: Button = findViewById(R.id.timerReturnBtn)

        timerReturnBtn.setOnClickListener {
            val intent = Intent(applicationContext, Welcome::class.java)
            startActivity(intent)
        }

        handler = Handler()

        startButton.setOnClickListener {
            if (isRunning) {
                pauseTimer()
            } else {
                startTimer()
            }
        }

        lapButton.setOnClickListener {
            if (isRunning) {
                lapTime = elapsedTime
                addLap()
            }
        }

        resetButton.setOnClickListener {
            resetTimer()
        }

    }
    private fun startTimer() {
        isRunning = true
        startButton.text = "Pause"
        lapButton.visibility = View.VISIBLE
        resetButton.visibility = View.GONE

        runnable = object : Runnable {
            override fun run() {
                elapsedTime = System.currentTimeMillis() - lapTime
                updateTimerText()

                handler.postDelayed(this, 10)
            }
        }
        handler.post(runnable)
    }

    private fun pauseTimer() {
        isRunning = false
        startButton.text = "Start"
        lapButton.visibility = View.GONE
        resetButton.visibility = View.VISIBLE

        handler.removeCallbacks(runnable)
    }

    private fun resetTimer() {
        isRunning = false
        lapCount = 1
        elapsedTime = 0L
        lapTime = 0L
        updateTimerText()

        startButton.text = "Start"
        lapButton.visibility = View.GONE
        resetButton.visibility = View.GONE

        handler.removeCallbacks(runnable)
    }

    private fun addLap() {
        val lapText = "Lap $lapCount: ${formatTime(lapTime)}"
        lapTimerText.append("\n$lapText")
        lapCount++
    }

    private fun updateTimerText() {
        lapTimerText.text = formatTime(elapsedTime)
    }

    private fun formatTime(timeInMillis: Long): String {
        val minutes = (timeInMillis / 1000) / 60
        val seconds = (timeInMillis / 1000) % 60
        val milliseconds = (timeInMillis % 1000) / 10

        return String.format("%02d:%02d:%02d", minutes, seconds, milliseconds)
    }
}