package com.example.apptemplate.view

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.apptemplate.R
import com.example.apptemplate.model.UserData

class UserAdapter(val c:Context,val tsList:ArrayList<UserData>) :RecyclerView.Adapter<UserAdapter.UserViewHolder>()
{

    inner class UserViewHolder(val v: View):RecyclerView.ViewHolder(v){
        val uCategory = v.findViewById<TextView>(R.id.category)
        val uName = v.findViewById<TextView>(R.id.Name)
        val uStartDate = v.findViewById<TextView>(R.id.startDate)
        val uEndDate = v.findViewById<TextView>(R.id.endDate)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): UserViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val v = inflater.inflate(R.layout.activity_view_timesheets,parent,false)
        return UserViewHolder(v)
    }

    override fun getItemCount(): Int {
        return tsList.size
    }

    override fun onBindViewHolder(holder: UserViewHolder, position: Int) {
        val newList = tsList[position]
        holder.uCategory.text = newList.userCategory
        holder.uName.text = newList.userName
        holder.uStartDate.text = newList.startDate
        holder.uEndDate.text = newList.endDate
    }
}