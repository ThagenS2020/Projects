package com.example.apptemplate.model

data class UserData (
    val userCategory:String,
    val userName:String,
    val startDate:String,
    val endDate:String
        )