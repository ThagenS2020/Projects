package com.example.apptemplate

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.database.*

class Calendar : AppCompatActivity() {
    private lateinit var recViewer:RecyclerView
    private lateinit var userList:ArrayList<User>
    private lateinit var dbRef:DatabaseReference
    private lateinit var load:TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_calendar)
        recViewer = findViewById(R.id.recView)

        recViewer.layoutManager = LinearLayoutManager(this)
        recViewer.setHasFixedSize(true)
        load = findViewById(R.id.userLoading)

        userList= arrayListOf<User>()
        getUserData()

        val calReturnBtn: Button = findViewById(R.id.calReturnBtn)

        calReturnBtn.setOnClickListener {
            val intent = Intent(applicationContext, Welcome::class.java)
            startActivity(intent)
        }

    }
    private fun getUserData(){
      recViewer.visibility= View.GONE
        load.visibility = View.VISIBLE
        dbRef=FirebaseDatabase.getInstance().getReference("User")
        dbRef.addValueEventListener(object :ValueEventListener{
            override fun onDataChange(snapshot: DataSnapshot) {
                userList.clear()
                if(snapshot.exists()){
                    for(empSnap in snapshot.children){
                        val userData = empSnap.getValue(User::class.java)
                        userList.add(userData!!)
                    }
                    val mAdapter = userAdapter(userList)
                    recViewer.adapter=mAdapter


                    recViewer.visibility=View.VISIBLE
                    load.visibility= View.GONE
                }
            }

            override fun onCancelled(error: DatabaseError) {
                TODO("Not yet implemented")
            }

        })

    }
}