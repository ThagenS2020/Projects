package com.example.apptemplate

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText


class Calculator : AppCompatActivity() {
    private var operand1: Double = 0.0
    private var operand2: Double = 0.0
    private var operator: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_calculator)
        val display = findViewById<EditText>(R.id.display)
        val calcReturnBtn:Button = findViewById(R.id.calcReturnBtn)
        // Set click listeners for number buttons

        calcReturnBtn.setOnClickListener {
            val intent = Intent(applicationContext, Welcome::class.java)
            startActivity(intent)
        }

        val numberButtons = listOf<Button>(
            findViewById(R.id.btn_0),
            findViewById(R.id.btn_1),
            findViewById(R.id.btn_2),
            findViewById(R.id.btn_3),
            findViewById(R.id.btn_4),
            findViewById(R.id.btn_5),
            findViewById(R.id.btn_6),
            findViewById(R.id.btn_7),
            findViewById(R.id.btn_8),
            findViewById(R.id.btn_9)
        )
        numberButtons.forEach { button ->
            button.setOnClickListener {
                val number = button.text.toString()
                display.append(number)
            }
        }

        // Set click listener for operator buttons
        val operatorButtons = listOf<Button>(
            findViewById(R.id.btn_plus),
            findViewById(R.id.btn_minus),
            findViewById(R.id.btn_multiply),
            findViewById(R.id.btn_divide)
        )
        operatorButtons.forEach { button ->
            button.setOnClickListener {
                operand1 = display.text.toString().toDouble()
                operator = button.text.toString()
                display.setText("")
            }
        }

        // Set click listener for equals button
        val equalsButton = findViewById<Button>(R.id.btn_equals)
        equalsButton.setOnClickListener {
            operand2 = display.text.toString().toDouble()
            val result = calculateResult()
            display.setText(result.toString())
        }

        // Set click listener for clear button
        val clearButton = findViewById<Button>(R.id.btn_clear)
        clearButton.setOnClickListener {
            display.setText("")
            operand1 = 0.0
            operand2 = 0.0
            operator = ""
        }

        // Set click listener for backspace button
        val backspaceButton = findViewById<Button>(R.id.btn_backspace)
        backspaceButton.setOnClickListener {
            val currentText = display.text.toString()
            if (currentText.isNotEmpty()) {
                display.setText(currentText.substring(0, currentText.length - 1))
            }
        }
    }
    private fun calculateResult(): Double {
        return when (operator) {
            "+" -> operand1 + operand2
            "-" -> operand1 - operand2
            "*" -> operand1 * operand2
            "/" -> operand1 / operand2
            else -> 0.0
        }
    }
}