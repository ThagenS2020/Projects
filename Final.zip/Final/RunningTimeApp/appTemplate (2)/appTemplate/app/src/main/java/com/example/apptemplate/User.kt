package com.example.apptemplate

data class User( val catergory:String? = null,val start:String? = null,val end:String? = null,val desc:String? = null,val nameProject:String? = null,val minimum:String? = null,val maximum:String? = null,val spentHours:String? = null)
