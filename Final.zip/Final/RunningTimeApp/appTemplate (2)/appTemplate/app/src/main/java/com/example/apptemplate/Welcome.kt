package com.example.apptemplate

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuItem
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AlertDialog
import androidx.drawerlayout.widget.DrawerLayout
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.apptemplate.model.UserData
import com.example.apptemplate.view.UserAdapter
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.navigation.NavigationView

class Welcome : AppCompatActivity() {
    lateinit var toggle: ActionBarDrawerToggle
    private lateinit var addsBtn: FloatingActionButton
    private lateinit var recv: RecyclerView
    private lateinit var tsList:ArrayList<UserData>
    private lateinit var userAdapter: UserAdapter
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_welcome)
        val drawerLayout: DrawerLayout = findViewById(R.id.drawerLayout)
        val navView: NavigationView = findViewById(R.id.nav_view)
        val addIT = findViewById<Button>(R.id.addingBtnIT)
        val itView = findViewById<EditText>(R.id.IT)


        addIT.setOnClickListener(){
            val itText = itView.text.toString()
            if(itText.isNotEmpty()) {
                val intent = Intent(this, TimeSheet::class.java)
                intent.putExtra("Catergory", itText)
                startActivity(intent)
            }else{
                Toast.makeText(applicationContext, "Requires category", Toast.LENGTH_SHORT).show()
            }

        }


        toggle = ActionBarDrawerToggle(this, drawerLayout, R.string.open, R.string.close)
        drawerLayout.addDrawerListener(toggle)
        toggle.syncState()
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        navView.setNavigationItemSelectedListener {

            when (it.itemId) {
                R.id.Home ->  {
                    val intent = Intent(applicationContext, Welcome::class.java)
                    startActivity(intent)
                }
                R.id.diagram ->  {
                    val intent = Intent(applicationContext, Graph::class.java)
                    startActivity(intent)
                }
                R.id.add -> {
                    val intent = Intent(applicationContext, Welcome::class.java)
                    startActivity(intent)
                }
                R.id.cal -> {
                    val intent = Intent(applicationContext, Calculator::class.java)
                    startActivity(intent)
                }
                R.id.time -> {
                    val intent = Intent(applicationContext, Timer::class.java)
                    startActivity(intent)
                }
                R.id.view ->  {
                    val intent = Intent(applicationContext, Calendar::class.java)
                    startActivity(intent)
                }
                R.id.register ->  {
                    val intent = Intent(applicationContext, register::class.java)
                    startActivity(intent)
                }
                R.id.details ->  {
                    val intent = Intent(applicationContext, account::class.java)
                    startActivity(intent)
                }
                R.id.out ->  {
                    val intent = Intent(applicationContext, MainActivity::class.java)
                    startActivity(intent)
                }
            }
            true

        }

    }
    override fun onOptionsItemSelected(item:MenuItem):Boolean{
        if (toggle.onOptionsItemSelected(item)){
            return true
        }
        return true
    }
}

