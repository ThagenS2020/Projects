package com.example.apptemplate

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class userAdapter (private val userList:ArrayList<User>):
    RecyclerView.Adapter<userAdapter.ViewHolder>(){


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): userAdapter.ViewHolder {
       val itemView = LayoutInflater.from(parent.context).inflate(R.layout.menu_list,parent,false)
       return ViewHolder(itemView)
    }

    override fun onBindViewHolder(holder:ViewHolder, position: Int) {
        val currentProject = userList[position]
        holder.projectName.text= currentProject.catergory
        holder.startDateR.text=currentProject.start
        holder.finishDate.text=currentProject.end
        holder.descrip.text=currentProject.desc
    }

    override fun getItemCount(): Int {
       return userList.size
    }
    class ViewHolder( itemView: View): RecyclerView.ViewHolder(itemView){
    val projectName:TextView = itemView.findViewById(R.id.catergoryOption)
        val startDateR:TextView=itemView.findViewById(R.id.startDateRec)
        val finishDate:TextView=itemView.findViewById(R.id.endDateRec)
        val descrip : TextView=itemView.findViewById(R.id.descriptionRec)

    }


}