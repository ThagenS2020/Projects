package com.example.apptemplate

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.google.firebase.FirebaseApp
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase

class TimeSheet : AppCompatActivity() {
    private lateinit var database : DatabaseReference
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_time_sheet)

        FirebaseApp.initializeApp(this)

        val projectName = findViewById<EditText>(R.id.projectName)
        val min = findViewById<EditText>(R.id.minHours)
        val max = findViewById<EditText>(R.id.maxHours)
        val beg = findViewById<EditText>(R.id.startDateEnter)
        val end = findViewById<EditText>(R.id.endDateEnter)
        val desc = findViewById<EditText>(R.id.description)
        val spent = findViewById<EditText>(R.id.hoursSpent)
        val receivedText = intent.getStringExtra("Catergory").toString()
        val add = findViewById<Button>(R.id.add)
        val cancel = findViewById<Button>(R.id.cancel)


        add.setOnClickListener(){
            val nameText = projectName.text.toString()
            val minText = min.text.toString()
            val maxText = max.text.toString()
            val spentText = spent.text.toString()
            val beginning = beg.text.toString()
            val finish = end.text.toString()
            val description = desc.text.toString()

            if(nameText.isEmpty()||minText.isEmpty()||maxText.isEmpty()||spentText.isEmpty()){
                Toast.makeText(this, "Fields must not be empty", Toast.LENGTH_SHORT).show()
            }else{
             database= FirebaseDatabase.getInstance().getReference("User")
                val users = User(receivedText,beginning,finish,description,nameText,minText,maxText,spentText)
                database.child(nameText).setValue(users).addOnSuccessListener {
                    Toast.makeText(this, "Saved Successfully ", Toast.LENGTH_SHORT).show()
                }.addOnFailureListener{
                    Toast.makeText(this, "Failed to save data ", Toast.LENGTH_SHORT).show()
                }
            }
        }
        cancel.setOnClickListener(){
            val intent = Intent(this,Welcome::class.java)
            startActivity(intent)
        }
    }
}
