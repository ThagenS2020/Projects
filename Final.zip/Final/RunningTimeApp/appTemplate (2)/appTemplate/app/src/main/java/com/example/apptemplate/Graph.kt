package com.example.apptemplate

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.graphics.Color
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast

class Graph : AppCompatActivity() {
    private lateinit var editText1: EditText
    private lateinit var editText2: EditText
    private lateinit var editText3: EditText
    private lateinit var btnDrawGraph: Button
    private lateinit var barChart: LinearLayout
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_graph)
        editText1 = findViewById(R.id.editText1)
        editText2 = findViewById(R.id.editText2)
        editText3 = findViewById(R.id.editText3)
        btnDrawGraph = findViewById(R.id.btnDrawGraph)
        barChart = findViewById(R.id.barChart)

        val btnReturn:Button = findViewById(R.id.btnReturn)

        btnReturn.setOnClickListener {
            val intent = Intent(applicationContext, com.example.apptemplate.Welcome::class.java)
            startActivity(intent)
        }

        btnDrawGraph.setOnClickListener {
            drawBarGraph()
        }
    }
    private fun drawBarGraph() {
        val value1 = editText1.text.toString().toFloatOrNull()
        val value2 = editText2.text.toString().toFloatOrNull()
        val value3 = editText3.text.toString().toFloatOrNull()

        val isInputValid = validateInput(value1, value2, value3)

        if (isInputValid) {
            barChart.removeAllViews()

            val max = listOfNotNull(value1, value2, value3).maxOrNull() ?: 1f
            val widthFactor = 100

            val params1 = LinearLayout.LayoutParams(
                (value1!! / max * widthFactor).toInt(),
                LinearLayout.LayoutParams.MATCH_PARENT
            )
            val params2 = LinearLayout.LayoutParams(
                (value2!! / max * widthFactor).toInt(),
                LinearLayout.LayoutParams.MATCH_PARENT
            )
            val params3 = LinearLayout.LayoutParams(
                (value3!! / max * widthFactor).toInt(),
                LinearLayout.LayoutParams.MATCH_PARENT
            )

            val bar1 = createBar(Color.RED, params1)
            val bar2 = createBar(Color.GREEN, params2)
            val bar3 = createBar(Color.BLUE, params3)

            barChart.addView(bar1)
            barChart.addView(bar2)
            barChart.addView(bar3)
        }
    }

    private fun createBar(color: Int, params: LinearLayout.LayoutParams): LinearLayout {
        val bar = LinearLayout(this)
        bar.layoutParams = params
        bar.setBackgroundColor(color)
        return bar
    }
    private fun validateInput(value1: Float?, value2: Float?, value3: Float?): Boolean {
        if (value1 == null || value2 == null || value3 == null) {
            Toast.makeText(this, "Please enter valid numeric values.", Toast.LENGTH_SHORT).show()
            return false
        }

        if (value1 <= 0 || value2 <= 0 || value3 <= 0) {
            Toast.makeText(this, "Please enter positive values.", Toast.LENGTH_SHORT).show()
            return false
        }

        return true
    }

}