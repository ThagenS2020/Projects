package com.project.birdseye.mvvmArch

import android.util.Log
import androidx.lifecycle.MutableLiveData
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.UserProfileChangeRequest
import com.project.birdseye.model.User
import com.project.birdseye.model.UserPreferences
import com.project.birdseye.util.FirebaseManager

class AuthRepo {

    private var firebaseUserLive = MutableLiveData<FirebaseUser?>()
    private var userLoggedIn = MutableLiveData<Boolean>()
    private var auth = FirebaseAuth.getInstance()

    init {
        if (auth.currentUser != null) {
            firebaseUserLive.value = auth.currentUser
        }
    }

    fun getFirebaseMutable(): MutableLiveData<FirebaseUser?> {
        return firebaseUserLive
    }

    fun getUserLoggedIn(): MutableLiveData<Boolean> {
        return userLoggedIn
    }

    fun register(
        email: String,
        pass: String,
        username: String,
        failureCallback: (Boolean) -> Unit
    ) {
        auth.createUserWithEmailAndPassword(email, pass).addOnCompleteListener { task ->
            if (task.isSuccessful) {
                firebaseUserLive.value = auth.currentUser
                userLoggedIn.value = true
                val setDisplayName =
                    UserProfileChangeRequest.Builder().setDisplayName(username).build()
                firebaseUserLive.value?.updateProfile(setDisplayName)
                Log.i("FirebaseUser", firebaseUserLive.value?.uid.toString())

                firebaseUserLive.value.apply {
                    val user = User(
                        this!!.uid, this.email.toString(), username,
                        userPreferences = UserPreferences()
                    )
                    FirebaseManager.registerUser(user) {
                        failureCallback(it)
                    }
                }
            } else
                failureCallback(false)
        }
    }

    fun login(email: String, pass: String, failureCallback: (String?) -> Unit) {
        auth.signInWithEmailAndPassword(email, pass).addOnCompleteListener { task ->
            if (task.isSuccessful) {
                firebaseUserLive.value = auth.currentUser
                userLoggedIn.value = true
                failureCallback("Success")
            } else {
                Log.e(
                    "LOGIN",
                    task.exception?.message ?: "Something went wrong with sign in"
                )
                failureCallback("Login Failed")
            }
        }
    }

    fun logout() {
        auth.signOut()
        firebaseUserLive.value = null
        userLoggedIn.value = false
    }
}