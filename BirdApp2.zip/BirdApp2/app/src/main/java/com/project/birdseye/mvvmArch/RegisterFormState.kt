package com.project.birdseye.mvvmArch

data class RegisterFormState(
    val emailError: Int? = null,
    val passwordError: Int? = null,
    val passwordMatch: Int? = null,
    val isDataValid: Boolean = false
)