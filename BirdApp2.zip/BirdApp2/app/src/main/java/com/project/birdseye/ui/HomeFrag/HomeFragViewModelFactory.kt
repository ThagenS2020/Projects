package com.project.birdseye.ui.HomeFrag

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider

class HomeFragViewModelFactory(private val homeFragRepo : HomeFragRepo) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return HomeFragViewModel(homeFragRepo) as T
    }
}