package com.project.birdseye.API

import android.util.Log
import com.google.android.gms.maps.model.LatLng
import com.project.birdseye.model.UserPreferences
import kotlinx.coroutines.*
import retrofit2.HttpException
import java.io.IOException

object Hotspots {
    fun  getHotspots(location : LatLng, preference: UserPreferences) {
        GlobalScope.launch(Dispatchers.IO) {
            Log.i("distance value", preference.maxDistance.toString())
            val response = try {
                RetrofitClient.birdHotspotsAPI?.getHotspots(
                    latitude = location.latitude,
                    longitude = location.longitude,
                    dist = preference.maxDistance//CurrentUser.mUser.userPreferences.maxDistance
                )

                //Log.i("MAIN", RetrofitClient.birdHotspotsAPI.toString())

            } catch (e: IOException) {
                Log.e("MAIN", "IOException. no internet connection")
                null
            } catch (e: HttpException) {
                Log.e("MAIN", "HTTPException. unexpected response")
                null
            }

            if (response != null) {
                Log.i("MAIN", response.toString())
                val results = response.body()!!
                MainScope().launch {
                    BirdCollection.results.value = results
                }
                Log.i("MAIN", results.toString())
            }
        }
    }
}