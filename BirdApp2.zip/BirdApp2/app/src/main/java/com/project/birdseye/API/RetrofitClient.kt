package com.project.birdseye.API

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object RetrofitClient {
    val birdHotspotsAPI: IBirdAPI? by lazy {
        Retrofit.Builder()
            .baseUrl("https://api.ebird.org/v2/ref/hotspot/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(IBirdAPI::class.java)
    }
}