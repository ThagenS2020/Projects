package com.project.birdseye.ui.main

import android.location.Geocoder
import android.os.Bundle
import android.webkit.URLUtil
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.project.birdseye.R
import com.project.birdseye.databinding.ActivityBirdDetailBinding


class BirdDetail : AppCompatActivity() {

    private lateinit var binding: ActivityBirdDetailBinding
    private lateinit var address : Geocoder

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setTheme(R.style.CustomNoActionBarTheme)
        binding = ActivityBirdDetailBinding.inflate(layoutInflater)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        setContentView(binding.root)

        address = Geocoder(this)


        val title = intent.extras?.getString("title")
        val image = intent.extras?.getString("img")
        val description = intent.extras?.getString("desc")
        val date = intent.extras?.getString("date")
        val location = intent.extras?.getString("location")

        val latlong = location!!.split(",".toRegex()).dropLastWhile { it.isEmpty() }
            .toTypedArray()

        val latitude: Double = latlong[0].toDouble()
        val longitude: Double = latlong[1].toDouble()
        val locationReadable = address.getFromLocation(
            latitude,
            longitude,
            1
        )!!.toList()
        setSupportActionBar(binding.toolbarBirdDetails)
        supportActionBar!!.setDisplayHomeAsUpEnabled(true)
        supportActionBar!!.title = title
        binding.toolbarBirdDetails.setNavigationOnClickListener {
            onBackPressed()
        }
    if(!URLUtil.isValidUrl(image)){
        Glide.with(this).load(R.drawable.ic_launcher_new_logo_foreground).into(binding.ivBirdImage)
    }else{
        Glide.with(this).load(image).into(binding.ivBirdImage)
    }
        var locationCapture = ""
        binding.tvDescription.text = description
        if (locationReadable[0].subLocality == null){
            locationCapture = "Captured this creature at ->\nCounty: ${locationReadable[0].subAdminArea}\nCity: ${locationReadable[0].locality}"
        }
        else locationCapture = "Captured this creature at ->\nCity: ${locationReadable[0].locality}\nSuburb: ${locationReadable[0].subLocality}"
        binding.tvLocation.text = locationCapture
        binding.tvDate.text = "Captured on: $date"
        binding.tvName.text = "Bird Name: $title"
    }
}