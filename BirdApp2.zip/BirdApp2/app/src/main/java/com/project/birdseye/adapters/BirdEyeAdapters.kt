package com.project.birdseye.adapters


import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import android.webkit.URLUtil
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.project.birdseye.R

import com.project.birdseye.databinding.ItemBirdBinding
import com.project.birdseye.model.BirdModel


class BirdEyeAdapters(private val context: Context, private var list: List<BirdModel>, private val recyclerInterface : recyclerInterface) :
    RecyclerView.Adapter<BirdEyeAdapters.ViewHolder>() {

    class ViewHolder(binding: ItemBirdBinding) :
        RecyclerView.ViewHolder(binding.root) {
        val tvTitle = binding.tvTitle
        val tvDescription = binding.tvDescription
        val ivPlaceImage = binding.ivBirdImage
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(
            ItemBirdBinding.inflate(
                LayoutInflater.from(context), parent, false
            )
        )
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val model: BirdModel = list[position]
        Log.i("URI", model.image!!)
        if(!URLUtil.isValidUrl(model.image)){
            Glide.with(context).load(R.mipmap.ic_launcher_logo_round).into(holder.ivPlaceImage)
        }else{
            Glide.with(context).load(model.image).into(holder.ivPlaceImage)
        }
        holder.tvTitle.text = model.title
        holder.tvDescription.text = model.description
        holder.itemView.setOnClickListener {
            recyclerInterface.onItemClick(position)
        }
    }

    override fun getItemCount(): Int {
        return list.size
    }
}
