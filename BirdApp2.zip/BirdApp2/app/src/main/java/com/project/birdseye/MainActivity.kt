package com.project.birdseye

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.LocationManager
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import com.google.android.gms.location.*
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.tasks.CancellationTokenSource
import com.project.birdseye.API.Hotspots
import com.project.birdseye.databinding.ActivityMainBinding
import com.project.birdseye.mvvmArch.AuthViewModel
import com.project.birdseye.ui.HomeFrag.HomeFragment
import com.project.birdseye.ui.main.AddBird
import com.project.birdseye.ui.main.ProfileFragment
import com.project.birdseye.ui.map.MapFragment
import com.project.birdseye.util.CurrentUser
import com.project.birdseye.util.DependencyInjection
import com.project.birdseye.util.FirebaseManager
import kotlinx.coroutines.DelicateCoroutinesApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch


class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var fusedLocation: FusedLocationProviderClient
    private lateinit var authViewModel: AuthViewModel
    private lateinit var address: Geocoder

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        installSplashScreen()
        setContentView(binding.root)
        supportFragmentManager.beginTransaction().apply {
            replace(R.id.fragment_container, HomeFragment())
            commit()
        }
        //initialize fragment
        binding.fabAddLocation.setOnClickListener {
            val intent = Intent(this, AddBird::class.java)
            startActivity(intent)
        }

        val navBottom = binding.bottomNavigation

        navBottom.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.Nav_Home -> {
                    binding.fabAddLocation.show()
                    //fragment transaction
                    supportFragmentManager.beginTransaction().apply {
                        replace(R.id.fragment_container, HomeFragment())
                        commit()
                    }
                    // Respond to navigation item 1 click
                    true
                }
                R.id.Nav_Maps -> {
                    binding.fabAddLocation.hide()
                    //fragment transaction
                    supportFragmentManager.beginTransaction().apply {
                        replace(R.id.fragment_container, MapFragment())
                        commit()
                    }
                    // Respond to navigation item 2 click
                    true
                }
                R.id.Nav_Profile -> {
                    binding.fabAddLocation.hide()
                    //fragment transaction
                    supportFragmentManager.beginTransaction().apply {
                        replace(R.id.fragment_container, ProfileFragment())
                        commit()
                    }
                    // Respond to navigation item 3 click
                    true
                }
                else -> false
            }
        }
    }

    override fun onStart() {
        super.onStart()
        fusedLocation = LocationServices.getFusedLocationProviderClient(this)
        val factory = DependencyInjection.provideAuthViewModelFactory()
        authViewModel = ViewModelProvider(this, factory)[AuthViewModel::class.java]
        authViewModel.getFirebaseMutable().observe(this) { loggedIn ->
            if (loggedIn != null)
                if (checkPermission()) {
                    if (isLocationEnabled()) {
                        lifecycleScope.launch(Dispatchers.IO) {
                            getCurrent()
                        }
                    } else {
                        //settings open
                        Toast.makeText(this, "Turn on Location", Toast.LENGTH_LONG).show()
                        val intent = Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)
                        startActivity(intent)
                    }
                } else {
                    //request perms
                    requestPermission()
                }
        }

    }


    @SuppressLint("MissingPermission")
    fun getCurrent() {
        val homeLocation = LatLng(-25.7601, 28.3394)
        address = Geocoder(this)
        lifecycleScope.launch(Dispatchers.IO) {
            val result = fusedLocation.getCurrentLocation(
                Priority.PRIORITY_HIGH_ACCURACY,
                CancellationTokenSource().token,
            )
            result.addOnCompleteListener { fetchedLocation ->
                fetchedLocation.result.let { res ->
                    Log.i(
                        "foundLocation",
                        "Current location is \n" + "lat : ${res.latitude}\n" +
                                "long : ${res.longitude}\n" + "fetched at ${System.currentTimeMillis()} from get current"
                    )
                    runOnUiThread {
                        CurrentUser.coordinates(res)
                        address = Geocoder(this@MainActivity)
                        CurrentUser.address = address.getFromLocation(
                            res.latitude,
                            res.longitude,
                            1
                        )!!.toList()
                        Log.i("near", CurrentUser.address.toString())
                        CurrentUser.setLocality()
                    }
                    FirebaseManager.getPreferences { userPref, dbError ->
                        Log.i("PREF", userPref.toString())
                        if (userPref != null) {
                            Hotspots.getHotspots(homeLocation, userPref)
                        }
                    }
                }

            }
//            val result = fusedLocation.getCurrentLocation(
//                Priority.PRIORITY_HIGH_ACCURACY,
//                CancellationTokenSource().token,
//            ).await()
//            result?.let { fetchedLocation: Location ->
//                Log.i(
//                    "foundLocation",
//                    "Current location is \n" + "lat : ${fetchedLocation.latitude}\n" +
//                            "long : ${fetchedLocation.longitude}\n" + "fetched at ${System.currentTimeMillis()} from get current"
//                )
//                runOnUiThread {
//                    CurrentUser.coordinates(fetchedLocation)
//                    address = Geocoder(this@MainActivity)
//                    CurrentUser.address = address.getFromLocation(
//                        fetchedLocation.latitude,
//                        fetchedLocation.longitude,
//                        1
//                    )!!.toList()
//                    Log.i("near", CurrentUser.address.toString())
//                    CurrentUser.setLocality()
//                }
//                FirebaseManager.getPreferences { userPref, dbError ->
//                    Log.i("PREF", userPref.toString())
//                    if (userPref != null) {
//                        Hotspots.getHotspots(CurrentUser.toLatLng(fetchedLocation), userPref)
//                    }
//                }
//            }
        }
    }


    private fun isLocationEnabled(): Boolean {
        val locationManager = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) ||
                locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)
    }

    //permissions request
    private fun requestPermission() {
        ActivityCompat.requestPermissions(
            this,
            arrayOf(
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION

            ),
            PERMISSION_REQUEST_ACCESS_LOCATION
        )
    }

    private fun checkPermission(): Boolean {
        return ActivityCompat.checkSelfPermission(
            this,
            Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED || ActivityCompat.checkSelfPermission(
            this,
            Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
    }

    @OptIn(DelicateCoroutinesApi::class)
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        if (requestCode == PERMISSION_REQUEST_ACCESS_LOCATION) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                GlobalScope.launch(Dispatchers.IO) {
                    getCurrent()
                    runOnUiThread {
                        Toast.makeText(applicationContext, "PERMISSION GRANTED", Toast.LENGTH_LONG)
                            .show()
                    }
                }
            } else {
                Toast.makeText(this, "PERMISSION DENIED", Toast.LENGTH_LONG).show()
            }
        }
    }

    companion object {
        private const val PERMISSION_REQUEST_ACCESS_LOCATION = 100
    }
}