package com.project.birdseye.ui.main

import android.Manifest
import android.annotation.SuppressLint
import android.app.DatePickerDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.tasks.CancellationTokenSource
import com.project.birdseye.MainActivity
import com.project.birdseye.R
import com.project.birdseye.databinding.ActivityAddingBirdBinding
import com.project.birdseye.model.BirdModel
import com.project.birdseye.util.FirebaseManager
import com.project.birdseye.util.CurrentUser
import com.swein.easypermissionmanager.EasyPermissionManager
import kotlinx.coroutines.*
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class AddBird : AppCompatActivity(), View.OnClickListener {
    private lateinit var binding: ActivityAddingBirdBinding
    private val defaultDispatcher: CoroutineDispatcher = Dispatchers.IO
    lateinit var fusedLocation : FusedLocationProviderClient

    @SuppressLint("MissingPermission")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_adding_bird)
        binding = ActivityAddingBirdBinding.inflate(layoutInflater)
        setSupportActionBar(binding.toolbarAddBird)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbarAddBird.setNavigationOnClickListener {
            onBackPressed()
        }
        binding.etDate.setOnClickListener(this)
        binding.lnImage.setOnClickListener(this)
        binding.btnSave.setOnClickListener(this)
        setContentView(binding.root)

        CurrentUser.location.observe(this){
            binding.etLocation.setText(CurrentUser.getLocation())
        }

        fusedLocation = LocationServices.getFusedLocationProviderClient(this)
        val result = fusedLocation.getCurrentLocation(
            Priority.PRIORITY_HIGH_ACCURACY,
            CancellationTokenSource().token,
        )
        result.addOnCompleteListener { fetchedLocation ->
            fetchedLocation.result.let {res ->
                Log.i(
                    "foundLocationBird",
                    "Current location is \n" + "lat : ${res.latitude}\n" +
                            "long : ${res.longitude}\n" + "fetched at ${System.currentTimeMillis()} from get current"
                )
            }
        }
    }

    override fun onClick(v: View?) {

        when (v!!.id) {
            R.id.et_date -> {
                val myCalendar = Calendar.getInstance()
                val year = myCalendar.get(Calendar.YEAR)
                val month = myCalendar.get(Calendar.MONTH)
                val day = myCalendar.get(Calendar.DAY_OF_MONTH)

                DatePickerDialog(
                    this,
                    { view, selectedYear, selectedMonth, selecteddayOfMonth ->
                        val selectedDate = "$selecteddayOfMonth/${selectedMonth - 1}/$selectedYear"
                        binding.etDate.text?.clear()
                        val sdf = SimpleDateFormat("MM/dd/yyyy", Locale.getDefault())
                        val date = sdf.parse(selectedDate)
                        binding.etDate.append(selectedDate)
                    },
                    year,
                    month,
                    day
                ).show()
            }
            R.id.lnImage -> {
                //pickImage.launch("image/*")
                permissionManager.requestPermission(
                    "Permission",
                    "permissions are necessary",
                    "setting",
                    arrayOf(
                        Manifest.permission.CAMERA,
                        Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE,
                        Manifest.permission.READ_EXTERNAL_STORAGE
                    )
                )
                 {
                    //permissions granted
                     getImageUri()
                }
            }
            R.id.btn_save -> {
                when {
                    binding.etTitle.text.isNullOrEmpty() -> {
                        Toast.makeText(this, "Please enter title", Toast.LENGTH_SHORT).show()
                    }
                    binding.etDescription.text.isNullOrEmpty() -> {
                        Toast.makeText(this, "Please enter description", Toast.LENGTH_SHORT)
                            .show()
                    }
                    else -> {
                        binding.svMain.visibility = View.GONE
                        binding.loadingLayout.visibility = View.VISIBLE
                            lifecycleScope.async {
                                saveBird()
                            }

                        // Assigning all the values to data model class.

                    }
                }
            }
        }
    }

    private fun changeIntent() {
        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
        this@AddBird.finish()
    }

    private fun getImageUri() {
        Toast.makeText(this, "All permission is ok, go go go", Toast.LENGTH_SHORT).show()
        uri = FileProvider.getUriForFile(
            this,
            "com.project.birdseye.provider",
            createImageFile().also {
                tempImageFilePath = it.absolutePath
            })
        takePicture.launch(uri)
    }



    private suspend fun saveBird() {
        withContext(defaultDispatcher) {
            val birdModel = BirdModel(
                UUID.randomUUID().toString(),
                binding.etTitle.text.toString(),
                uri.toString(),
                binding.etDescription.text.toString(),
                binding.etDate.text.toString(),
                CurrentUser.getLocationRaw(),
            )
            if(uri != null) {
                Log.e("URI TEST", uri.toString())
                FirebaseManager.saveImage(birdModel.id!!, uri!!) { url ->
                    birdModel.image = url
                    FirebaseManager.saveBird(birdModel){complete ->
                        if (complete)
                            changeIntent()
                    }
                }
            }else{
                FirebaseManager.saveBird(birdModel){complete ->
                    if (complete)
                        changeIntent()
                }
            }
        }
    }

    //all code below relating to image capture is attributed
    //Link : https://www.youtube.com/watch?v=a83eizMrE6Y
    private val permissionManager = EasyPermissionManager(this)
    private var tempImageFilePath = "" //maybe used
    private var uri: Uri? = null
    private val takePicture =
        registerForActivityResult(ActivityResultContracts.TakePicture()) { success ->
            if (success) {
                binding.ivPlaceImage.setImageURI(uri)
            }
        }

    fun createImageFile(): File {
        val storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES)
        return File.createTempFile("temp_image", ".jpg", storageDir)
    }
}