package com.project.birdseye.ui.login

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.View
import android.widget.EditText
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.project.birdseye.MainActivity
import com.project.birdseye.databinding.ActivityLoginBinding
import com.project.birdseye.mvvmArch.AuthViewModel
import com.project.birdseye.ui.register.RegisterActivity
import com.project.birdseye.util.DependencyInjection
import com.project.birdseye.util.FirebaseManager

class LoginActivity : AppCompatActivity() {
    private lateinit var authViewModel: AuthViewModel
    private lateinit var binding: ActivityLoginBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.createAccount.setOnClickListener {
            val intent = Intent(this, RegisterActivity::class.java)
            startActivity(intent)
            this.finish()
        }


        val factory = DependencyInjection.provideAuthViewModelFactory()
        val username = binding.username
        val password = binding.password
        val login = binding.login
        login.isEnabled = false
        val error = binding.errorMessage
        error.visibility = View.GONE
        authViewModel = ViewModelProvider(this, factory)[AuthViewModel::class.java]

        //if user is signed in,, skip login
        val userSignIn = authViewModel.getFirebaseMutable().value
        Log.i("LOG",userSignIn.toString())
        if (userSignIn != null) {
            FirebaseManager.currentUser = authViewModel.getFirebaseMutable()
            Log.i("USER", "${userSignIn.displayName}")
            val intent = Intent(this@LoginActivity, MainActivity::class.java)
            this@LoginActivity.startActivity(intent)
            this@LoginActivity.finish()
        }


        authViewModel.loginFormState.observe(this, Observer { value ->
            val loginState = value ?: return@Observer

            login.isEnabled = loginState.isDataValid

            if (loginState.usernameError != null) {
                username.error = getString(loginState.usernameError)
            }

            if (loginState.passwordError != null) {
                password.error = getString(loginState.passwordError)
            } else {
                password.error = null
            }

        })

        username.afterTextChanged {
            authViewModel.loginDataChanged(
                username.text.toString(), password.text.toString()
            )
            error.visibility = View.INVISIBLE
        }

        password.afterTextChanged {
            authViewModel.loginDataChanged(
                username.text.toString(), password.text.toString()
            )
            error.visibility = View.INVISIBLE
        }

        login.setOnClickListener {
            authViewModel.login(username.text.toString(), password.text.toString()) {
                //if failure then
                Log.e("trial", it.toString())
                if (it.equals("Login Failed")) {
                    error.visibility = View.VISIBLE
                } else {
                    FirebaseManager.currentUser = authViewModel.getFirebaseMutable()
                    val intent = Intent(this@LoginActivity, MainActivity::class.java)
                    this@LoginActivity.startActivity(intent)
                    this@LoginActivity.finish()
                }
            }
        }
    }
}


/**
 * Extension function to simplify setting an afterTextChanged action to EditText components.
 */
fun EditText.afterTextChanged(afterTextChanged: (String) -> Unit) {
    this.addTextChangedListener(object : TextWatcher {
        override fun afterTextChanged(editable: Editable?) {
            afterTextChanged.invoke(editable.toString())
        }

        override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {}

        override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {}
    })
}