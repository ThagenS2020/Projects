package com.project.birdseye.adapters

interface recyclerInterface {
    fun onItemClick(pos : Int)
}