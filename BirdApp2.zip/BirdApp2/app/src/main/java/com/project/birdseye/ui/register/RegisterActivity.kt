package com.project.birdseye.ui.register

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.EditText
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import com.project.birdseye.MainActivity
import com.project.birdseye.databinding.ActivityRegisterBinding
import com.project.birdseye.mvvmArch.AuthViewModel
import com.project.birdseye.util.DependencyInjection
import androidx.lifecycle.Observer
import com.project.birdseye.ui.login.LoginActivity
import com.project.birdseye.util.FirebaseManager


class RegisterActivity : AppCompatActivity() {
    private lateinit var authViewModel: AuthViewModel
    private lateinit var binding: ActivityRegisterBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.Login.setOnClickListener {
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
            this.finish()
        }

        val factory = DependencyInjection.provideAuthViewModelFactory()
        val username = binding.username
        val email = binding.email
        val password = binding.password
        val confirmPass = binding.confirmPassword
        val register = binding.register
        register.isEnabled = false
        val error = binding.errorMessage

        error.visibility = View.GONE
        authViewModel = ViewModelProvider(this, factory)[AuthViewModel::class.java]

        authViewModel.registerFormState.observe(this, Observer { value ->
            val registerState = value ?: return@Observer

            register.isEnabled = registerState.isDataValid

            if (registerState.emailError != null) {
                binding.emailInput.error = getString(registerState.emailError)
            } else binding.emailInput.error = null

            if (registerState.passwordError != null) {
                binding.passwordInputLayout.error = getString(registerState.passwordError)
            } else binding.passwordInputLayout.error = null

            if (registerState.passwordMatch != null) {
                binding.confirmPassLayout.error = getString(registerState.passwordMatch)
            } else binding.confirmPassLayout.error = null
        })

        email.afterTextChanged {
            authViewModel.registerDataChanged(
                email.text.toString(),
                password.text.toString(),
                confirmPass.text.toString()
            )
            error.visibility = View.INVISIBLE
        }

        password.afterTextChanged {
            authViewModel.registerDataChanged(
                email.text.toString(),
                password.text.toString(),
                confirmPass.text.toString()
            )
            error.visibility = View.INVISIBLE
        }

        confirmPass.afterTextChanged {
            authViewModel.registerDataChanged(
                email.text.toString(),
                password.text.toString(),
                confirmPass.text.toString()
            )
            error.visibility = View.INVISIBLE
        }

        register.setOnClickListener {
            authViewModel.register(
                email.text.toString(),
                password.text.toString(),
                username.text.toString()
            ) { isValid ->
                if (isValid) {
                    Toast.makeText(this, "Registration successful", Toast.LENGTH_LONG).show()
                    FirebaseManager.currentUser = authViewModel.getFirebaseMutable()
                    val intent =
                        Intent(this, MainActivity::class.java)
                    startActivity(intent)
                    this.finish()
                }else{
                    Toast.makeText(this, "Registration unsuccessful", Toast.LENGTH_LONG).show()
                    error.visibility = View.VISIBLE
                    return@register
                }
            }

        }
    }

    /**
     * Extension function to simplify setting an afterTextChanged action to EditText components.
     */
    fun EditText.afterTextChanged(afterTextChanged: (String) -> Unit) {
        this.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(editable: Editable?) {
                afterTextChanged.invoke(editable.toString())
            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {}
        })
    }
}