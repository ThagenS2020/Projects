package com.project.birdseye.mvvmArch

import android.util.Patterns
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.google.firebase.auth.FirebaseUser
import com.project.birdseye.R

class AuthViewModel(private val authRepo: AuthRepo) : ViewModel() {

    private var userData = MutableLiveData<FirebaseUser?>()
    private var userLoggedStatus = MutableLiveData<Boolean>()

    private val _loginForm = MutableLiveData<LoginFormState>()
    val loginFormState: LiveData<LoginFormState> = _loginForm

    private val _registerForm = MutableLiveData<RegisterFormState>()
    val registerFormState: LiveData<RegisterFormState> = _registerForm

    fun getFirebaseMutable(): MutableLiveData<FirebaseUser?> {
        return userData
    }

    fun getUserLoggedIn(): MutableLiveData<Boolean> {
        return userLoggedStatus
    }

    init {
        userData = authRepo.getFirebaseMutable()
        userLoggedStatus = authRepo.getUserLoggedIn()
    }

    fun register(email: String, pass: String, username: String, failureCallback: (Boolean) -> Unit) {
        authRepo.register(email, pass, username, failureCallback)
    }

    fun login(email: String, pass: String, failureCallback : (String?) -> Unit) {
        authRepo.login(email, pass, failureCallback)
    }

    fun logout() {
        authRepo.logout()
    }

    //login and validation
    fun loginDataChanged(username: String, password: String) {
        if (!isUserNameValid(username)) {
            _loginForm.value = LoginFormState(usernameError = R.string.invalid_username)
            return
        }
        if (!isPasswordValid(password)) {
            _loginForm.value = LoginFormState(passwordError = R.string.invalid_password)
            return
        }
        _loginForm.value = LoginFormState(isDataValid = true)
    }

    private fun isUserNameValid(username: String): Boolean {
        if (Patterns.EMAIL_ADDRESS.matcher(username).matches()) {
            return true
        }
        return false
    }

    private fun isPasswordValid(password: String): Boolean {
        return password.length >= 6
    }

    private fun isPasswordMatch(password: String, confirmPass: String): Boolean {
        return password == confirmPass
    }

    fun registerDataChanged(username: String, password: String, confirmPass: String) {
        if (!isUserNameValid(username)) {
            _registerForm.value = RegisterFormState(emailError = R.string.invalid_email)
            return
        }
        if (!isPasswordValid(password)) {
            _registerForm.value = RegisterFormState(passwordError = R.string.invalid_password)
            return
        }
        if (!isPasswordMatch(password, confirmPass)) {
            _registerForm.value = RegisterFormState(passwordMatch = R.string.password_match)
            return
        }
        _registerForm.value = RegisterFormState(isDataValid = true)
    }
}