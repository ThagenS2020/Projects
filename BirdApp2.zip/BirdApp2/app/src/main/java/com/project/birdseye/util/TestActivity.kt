package com.project.birdseye.util

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.RequiresPermission
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.tasks.CancellationTokenSource
import com.google.android.material.snackbar.Snackbar
import com.project.birdseye.R
import com.project.birdseye.databinding.ActivityTestBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

//import com.example.platform.base.PermissionBox

class TestActivity : AppCompatActivity() {
    private lateinit var binding: ActivityTestBinding
    private lateinit var fusedLocation: FusedLocationProviderClient
    private var locationInfo: String? = null

    @SuppressLint("MissingPermission")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTestBinding.inflate(layoutInflater)
        setContentView(binding.root)

        //onClickRequestPermission(binding.result)

        binding.test.setOnClickListener {
            GlobalScope.launch(Dispatchers.IO) {
                val result = fusedLocation.lastLocation.await()
                locationInfo = if (result == null) {
                    "No last known location. Try fetching the current location first"
                } else {
                    "Current location is \n" + "lat : ${result.latitude}\n" +
                            "long : ${result.longitude}\n" + "fetched at ${System.currentTimeMillis()}"
                }
                runOnUiThread {
                    binding.result.append(locationInfo)
                }
            }
        }

        binding.test2.setOnClickListener {
            GlobalScope.launch(Dispatchers.IO) {
                val result = fusedLocation.getCurrentLocation(
                    Priority.PRIORITY_HIGH_ACCURACY,
                    CancellationTokenSource().token,
                ).await()
                result?.let { fetchedLocation: Location ->
                    locationInfo =
                        "Current location is \n" + "lat : ${fetchedLocation.latitude}\n" +
                                "long : ${fetchedLocation.longitude}\n" + "fetched at ${System.currentTimeMillis()}"
                }
                runOnUiThread {
                    binding.result.append(locationInfo)
                }
            }
        }


    }

    override fun onStart() {
        super.onStart()

        fusedLocation = LocationServices.getFusedLocationProviderClient(this)

        getLocation()
    }

    @SuppressLint("MissingPermission")
    suspend fun getCurrent() {
        GlobalScope.launch(Dispatchers.IO) {
            val result = fusedLocation.getCurrentLocation(
                Priority.PRIORITY_HIGH_ACCURACY,
                CancellationTokenSource().token,
            ).await()
            result?.let { fetchedLocation: Location ->
                runOnUiThread {
                    binding.result.append(
                        "Current location is \n" + "lat : ${fetchedLocation.latitude}\n" +
                                "long : ${fetchedLocation.longitude}\n" + "fetched at ${System.currentTimeMillis()} from get current"
                    )
                }
            }
        }
    }

    private fun getLocation() {
        if (checkPermission()) {
            if (isLocationEnabled()) {
                GlobalScope.launch(Dispatchers.IO) {
                    val result = fusedLocation.lastLocation.await()
                    if (result == null) {
                        getCurrent()
                    } else {
                        runOnUiThread {
                            binding.result.append(
                                "Current location is \n" + "lat : ${result.latitude}\n" +
                                        "long : ${result.longitude}\n" + "fetched at ${System.currentTimeMillis()} from get last"
                            )
                        }
                    }
                }
            } else {
                //settings open
                Toast.makeText(this, "Turn on Location", Toast.LENGTH_LONG).show()
                val intent = Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)
                startActivity(intent)
            }
        } else {
            //request perms
            requestPermission()
        }
    }

    private fun isLocationEnabled(): Boolean {
        val locationManager = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) ||
                locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)
    }

    private fun requestPermission() {
        ActivityCompat.requestPermissions(
            this,
            arrayOf(
                Manifest.permission.ACCESS_COARSE_LOCATION,
                Manifest.permission.ACCESS_FINE_LOCATION
            ),
            PERMISSION_REQUEST_ACCESS_LOCATION
        )
    }

    private fun checkPermission(): Boolean {
        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_COARSE_LOCATION
            )
            == PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            return true
        }
        return false
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        if (requestCode == PERMISSION_REQUEST_ACCESS_LOCATION) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Granted", Toast.LENGTH_LONG).show()
                getLocation()
            } else {
                Toast.makeText(this, "Granted", Toast.LENGTH_LONG).show()
            }
        }
    }


    companion object {
        private const val PERMISSION_REQUEST_ACCESS_LOCATION = 100
    }
}