package com.project.birdseye.ui.map

import android.Manifest
import android.content.DialogInterface
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AlertDialog
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.model.*
import com.google.maps.DirectionsApiRequest
import com.google.maps.GeoApiContext
import com.google.maps.PendingResult
import com.google.maps.internal.PolylineEncoding
import com.google.maps.model.DirectionsResult
import com.project.birdseye.API.BirdCollection
import com.project.birdseye.R
import com.project.birdseye.databinding.FragmentMapBinding
import com.project.birdseye.model.PolylineData
import com.project.birdseye.util.CurrentUser
import com.project.birdseye.util.DependencyInjection


class MapFragment : Fragment(), OnMapReadyCallback, GoogleMap.OnInfoWindowClickListener,
    GoogleMap.OnPolylineClickListener {

    private lateinit var mMap: GoogleMap
    private lateinit var binding: FragmentMapBinding
    private val DEFAULT_ZOOM: Float = 16f
    private lateinit var factory: MapFragViewModelFactory
    private lateinit var viewModel: MapFragViewModel
    private lateinit var geoApiContext: GeoApiContext
    private var polylineData: ArrayList<PolylineData> = ArrayList()
    private var tripMarkers: ArrayList<Marker> = ArrayList()
    private var selectedMarker: Marker? = null

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.mapView.onCreate(savedInstanceState)
        binding.mapView.onResume()
        binding.mapView.getMapAsync(this)
        geoApiContext = GeoApiContext.Builder().apiKey(getString(R.string.key)).build()
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentMapBinding.inflate(inflater, container, false)
        factory = DependencyInjection.provideMapFragViewModelFactory()
        viewModel = ViewModelProvider(this, factory)[MapFragViewModel::class.java]

        binding.btnResetMap.setOnClickListener{
            initMap()
        }

        return binding.root
    }

    //ALL code pertaining to polylines attributed from https://www.youtube.com/watch?v=3f09neIN89o&list=PLgCYzUzKIBE-SZUrVOsbYMzH7tPigT3gi&index=21
    //Author : CodingWithMitch
    //Date : 13 Nov 2023

    private fun resetMap() {
        if (mMap != null) {
            mMap.clear()
        }
        if (polylineData.size > 0) {
            polylineData.clear()
            polylineData = ArrayList()
        }
    }

    private fun removeTripMarkers() {
        for (item in tripMarkers) {
            item.remove()
        }
    }

    private fun resetSelectedMarker() {
        if (selectedMarker != null) {
            selectedMarker!!.isVisible = true
            selectedMarker = null
            removeTripMarkers()
        }
    }

    private fun addPolylinesToMap(result: DirectionsResult) {
        Handler(Looper.getMainLooper()).post(Runnable {

            if (polylineData.size > 0) {
                for (item in polylineData) {
                    item.polyline.remove()
                }
            }
            polylineData.clear()
            polylineData = ArrayList()

            var duration: Long = 9999999
            Log.d("MAIN", "run: result routes: " + result.routes.size)
            for (route in result.routes) {
                Log.d("MAIN", "run: leg: " + route.legs[0].toString())
                val decodedPath = PolylineEncoding.decode(route.overviewPolyline.encodedPath)
                val newDecodedPath: MutableList<LatLng> = ArrayList()

                // This loops through all the LatLng coordinates of ONE polyline.
                for (latLng in decodedPath) {

//                        Log.d(TAG, "run: latlng: " + latLng.toString());
                    newDecodedPath.add(
                        LatLng(
                            latLng.lat,
                            latLng.lng
                        )
                    )
                }
                val polyline: Polyline =
                    mMap.addPolyline(PolylineOptions().addAll(newDecodedPath))
                polyline.color = ContextCompat.getColor(activity!!, R.color.gray_polyline)
                polyline.isClickable = true
                polylineData.add(PolylineData(polyline, route.legs[0]))

                var tempDuration: Long = route.legs[0].duration.inSeconds
                if (tempDuration < duration) {
                    duration = tempDuration
                    onPolylineClick(polyline)
                    zoomRoute(polyline.points)
                }

                selectedMarker!!.isVisible = false
            }
        })
    }

    override fun onMapReady(map: GoogleMap) {
//        try {
//            map.setMapStyle(MapStyleOptions.loadRawResourceStyle(context!!, R.raw.map_styles))
//        } catch (e: NotFoundException) {
//            Log.i("LOST", e.toString())
//        }
        mMap = map
        mMap.uiSettings.isCompassEnabled = false
        mMap.setOnPolylineClickListener(this)
        mMap.setOnInfoWindowClickListener(this)
        initMap()
    }

    private fun initMap() {
        resetMap()
        mMap.let { theMap ->
            CurrentUser.location.observe(this@MapFragment, Observer { current ->
                if (ActivityCompat.checkSelfPermission(
                        context!!,
                        Manifest.permission.ACCESS_FINE_LOCATION
                    ) != PackageManager.PERMISSION_GRANTED
                ) {
                    return@Observer
                }
                theMap.isMyLocationEnabled = true
                moveCamera(CurrentUser.toLatLng(current))
                Log.i("MAIN", "Collection is: ${BirdCollection.results}")

            })

            BirdCollection.results.observe(this, Observer { birds ->
                Log.i("BIRDS OBS", birds.toString())
                Log.i("BIRDS OBS 2", BirdCollection.results.toString())
                for (item in birds) {
                    item.lat?.let { lat -> item.lng?.let { long -> LatLng(lat, long) } }
                        ?.let { drawCircle(it) }
                    val sighting =
                        item.lat?.let { lat -> item.lng?.let { long -> LatLng(lat, long) } }

                    sighting?.let { sight ->
                        MarkerOptions().position(sight).title(item.locName)
                    }
                        ?.let { marker -> theMap.addMarker(marker) }
                }
            })

            viewModel.birds.observe(this, Observer { localBirds ->
                if (localBirds == null)
                    return@Observer
                if (localBirds.isEmpty())
                    return@Observer
                for (item in localBirds) {
                    val locationRaw = item.location!!.split(",".toRegex())
                        .dropLastWhile { it.isEmpty() }
                        .toTypedArray()
                    val latitude = locationRaw[0].toDouble()
                    val longitude = locationRaw[1].toDouble()
                    val sighting = LatLng(latitude, longitude)

                    sighting.let { sight ->
                        MarkerOptions().position(sight).title(item.title)
                    }
                        .let { marker ->
                            theMap.addMarker(marker)!!.setIcon(
                                BitmapDescriptorFactory
                                    .defaultMarker(BitmapDescriptorFactory.HUE_AZURE)
                            )
                        }
                }
            })
            viewModel.getBirds()
        }
    }

    private fun moveCamera(loc: LatLng) {
        mMap.moveCamera(
            CameraUpdateFactory.newLatLngZoom(
                LatLng(loc.latitude, loc.longitude),
                DEFAULT_ZOOM
            )
        )
    }

    fun zoomRoute(lstLatLngRoute: List<LatLng?>?) {
        if (mMap == null || lstLatLngRoute == null || lstLatLngRoute.isEmpty()) return
        val boundsBuilder = LatLngBounds.Builder()
        for (latLngPoint in lstLatLngRoute) boundsBuilder.include(latLngPoint!!)
        val routePadding = 120
        val latLngBounds = boundsBuilder.build()
        mMap.animateCamera(
            CameraUpdateFactory.newLatLngBounds(latLngBounds, routePadding),
            600,
            null
        )
    }


    //code attributed from CodePlayon
    // Link https://codeplayon.medium.com/how-to-draw-a-circle-around-marker-on-google-map-in-android-d8122e434a93
    private fun drawCircle(point: LatLng) {    // Instantiating CircleOptions to draw a circle around the marker
        val circleOptions = CircleOptions()
        // Specifying the center of the circle
        circleOptions.center(point)
        // Radius of the circle
        circleOptions.radius(100.0)
        // Border color of the circle
        circleOptions.strokeColor(Color.BLACK)
        // Fill color of the circle
        circleOptions.fillColor(0x30ff0000)
        // Border width of the circle
        circleOptions.strokeWidth(2f)
        // Adding the circle to the GoogleMap
        mMap.addCircle(circleOptions)
    }

    //Code attributed from https://www.youtube.com/watch?v=f47L1SL5S0o&list=PLgCYzUzKIBE-SZUrVOsbYMzH7tPigT3gi&index=19
    //Author: CodingWithMitch
    //Date : 13 Nov 2023
    private fun calculateDirections(marker: Marker) {
        Log.d("MAP", "calculateDirections: calculating directions.")
        val destination = com.google.maps.model.LatLng(
            marker.position.latitude,
            marker.position.longitude
        )
        val directions = DirectionsApiRequest(geoApiContext)
        directions.alternatives(true)
        directions.origin(
            com.google.maps.model.LatLng(
                CurrentUser.latLocal!!,
                CurrentUser.longLocal!!
            )
        )
        Log.d("MAP", "calculateDirections: destination: $destination")
        directions.destination(destination)
            .setCallback(object : PendingResult.Callback<DirectionsResult?> {
                override fun onResult(result: DirectionsResult?) {
                    if (result != null) {
                        Log.d("MAP", "calculateDirections: routes: " + result.routes[0].toString())
                        Log.d(
                            "MAP",
                            "calculateDirections: geocodedWayPoints: " + result.geocodedWaypoints[0]
                                .toString()
                        )

                        addPolylinesToMap(result)
                    }
                }

                override fun onFailure(e: Throwable) {
                    Log.e("MAP", "calculateDirections: Failed to get directions: " + e.message)
                }
            })
    }

    override fun onPolylineClick(polyline: Polyline) {
        polyline.color = R.color.button_background_color
        polyline.zIndex = 1F

        var index = 0
        for (polylineData in polylineData) {
            index++
            Log.d("MAP", "onPolylineClick: toString: $polylineData")
            if (polyline.id.equals(polylineData.polyline.getId())) {
                polylineData.polyline.color =
                    ContextCompat.getColor(activity!!, R.color.blue_polyline)
                polylineData.polyline.zIndex = 1F

                val endLocation = LatLng(
                    polylineData.leg.endLocation.lat,
                    polylineData.leg.endLocation.lng
                )

                val marker = mMap.addMarker(
                    MarkerOptions()
                        .position(endLocation)
                        .title("Trip: #$index")
                        .snippet("Duration: ${polylineData.leg.duration}")
                )
                marker!!.showInfoWindow()
                tripMarkers.add(marker)

            } else {
                polylineData.polyline.color =
                    ContextCompat.getColor(activity!!, R.color.gray_polyline)
                polylineData.polyline.zIndex = 0F
            }
        }
    }

    override fun onInfoWindowClick(marker: Marker) {
        val builder = AlertDialog.Builder(activity!!)
        builder.setMessage("Travel to this location?")
            .setCancelable(true)
            .setPositiveButton("Yes",
                DialogInterface.OnClickListener { dialog, id ->
                    resetSelectedMarker()
                    calculateDirections(marker)
                    selectedMarker = marker
                    dialog.dismiss()
                })
            .setNegativeButton("No",
                DialogInterface.OnClickListener { dialog, id -> dialog.cancel() })
        val alert: AlertDialog = builder.create()
        alert.show()
    }
}