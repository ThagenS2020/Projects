package com.project.birdseye.model


data class BirdModel(
    val id: String?,
    val title: String?,
    var image: String?,
    val description: String?,
    val date: String?,
    val location: String?,
)
