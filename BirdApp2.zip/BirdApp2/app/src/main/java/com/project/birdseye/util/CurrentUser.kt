package com.project.birdseye.util

import android.location.Address
import android.location.Location
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.google.android.gms.maps.model.LatLng

object CurrentUser {
    private var _location = MutableLiveData<Location>()
    var location: LiveData<Location> = _location
    var city: String? = null
    var country: String? = null
    var suburb: String? = null
    var latLocal : Double? = null
    var longLocal : Double? = null
    var address : List<Address> = listOf()

    fun coordinates(location :Location) {
        _location.value = location
        latLocal = _location.value!!.latitude
        longLocal = _location.value!!.longitude
    }

    fun getLocation() : String = "$suburb, $city, $country"


    fun getLocationRaw() : String ="$latLocal, $longLocal"

    fun toLatLng(location: Location) : LatLng = LatLng(location.latitude, location.longitude)

    fun setLocality(){
        if (address[0].subLocality == null){
            recordSuburb(address[0].locality)
            recordCity(address[0].subAdminArea)
        }else
        {
            recordSuburb(address[0].subLocality)
            recordCity(address[0].locality)
        }
        recordCountry(address[0].countryName)
    }

    private fun recordCity(city: String) {
        CurrentUser.city = city
    }

    private fun recordCountry(country: String) {
        CurrentUser.country = country
    }

    private fun recordSuburb(sub : String) {
        suburb = sub
    }
}