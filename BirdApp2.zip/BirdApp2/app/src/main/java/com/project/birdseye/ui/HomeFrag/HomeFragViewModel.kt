package com.project.birdseye.ui.HomeFrag

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.project.birdseye.model.BirdModel
import com.project.birdseye.util.FirebaseManager
import kotlinx.coroutines.Job
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.launch

class HomeFragViewModel(private val homeFragRepo: HomeFragRepo) : ViewModel() {

    private val _birds = MutableLiveData<List<BirdModel>?>()
    val birds : LiveData<List<BirdModel>?> = _birds
    private lateinit var job : Job

    init {
        // Initialize LiveData as null
        _birds.value = null
    }

    fun getBirds(){
        viewModelScope.launch{
            job = FirebaseManager.ioToFrag {
                homeFragRepo.getBirds { resultList ->
                    MainScope().launch {
                        _birds.value = resultList
                    }
                }
            }
        }
    }
}