package com.project.birdseye.util

import android.net.Uri
import android.util.Log
import androidx.lifecycle.MutableLiveData
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.database.*
import com.google.firebase.storage.FirebaseStorage
import com.project.birdseye.model.BirdModel
import com.project.birdseye.model.User
import com.project.birdseye.model.UserPreferences
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.launch

object FirebaseManager {
    private val database: FirebaseDatabase = FirebaseDatabase.getInstance()
    private val refUsers: DatabaseReference = database.getReference("users")
    private val storageReference =
        FirebaseStorage.getInstance()
    var currentUser: MutableLiveData<FirebaseUser?>? = null
    //private val currentUserID = currentUser!!.value!!.uid

    fun savePreferences(userPref: UserPreferences, completeListener: () -> Unit) {
        val user = refUsers.child(getCurrentUserID()).child("userPreferences")
        user.setValue(userPref).addOnCompleteListener {
            completeListener()
        }
    }

    fun getPreferences(prefCallback: (UserPreferences?, DatabaseError?) -> Unit) {
        if (getCurrentUserID().isNotEmpty()) {
            val user = refUsers.child(getCurrentUserID()).child("userPreferences")
            user.addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    if (snapshot.exists()) {
                        val userPreference = snapshot.getValue(UserPreferences::class.java)
                        //val system = snapshot.child("measurementSystem").getValue(String::class.java)
                        Log.i("FROM DB", userPreference!!.maxDistance.toString())
                        prefCallback(userPreference, null)
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    prefCallback(null, error)
                }
            })
        }
    }


    fun registerUser(user: User, isComplete: (Boolean) -> Unit) {
        refUsers.child(user.id).setValue(user).addOnCompleteListener {
            isComplete(true)
        }
    }

    fun getCurrentUserID(): String {
        if (currentUser?.value != null)
            return currentUser!!.value!!.uid
        return "empty"
    }

    //First upload image, then retrieve the image url THEN save the reference into the realtime DB
    fun saveBird(bird: BirdModel, successCall: (Boolean) -> Unit) {
        refUsers.child(getCurrentUserID()).child("sightings")
            .child(bird.id.toString()).setValue(bird).addOnCompleteListener {
                successCall(true)
            }
    }

    fun saveImage(birdId: String, uri: Uri, successCall: (String) -> Unit) {
        if (getCurrentUserID().isNotEmpty()) {
            val imageRef = storageReference.getReference(getCurrentUserID()).child(birdId)
            imageRef.putFile(uri)
                .addOnSuccessListener { task ->
                    imageRef.downloadUrl
                        .addOnSuccessListener { imageUrl ->
                            Log.i("IMAGE", "image stored successfully")
                            Log.i("IMAGE", imageUrl.toString())
                            successCall(imageUrl.toString())
                        }
                }
                .addOnFailureListener { e ->
                    Log.e("IMAGE", "Error storing image: $e")
                }
        }
    }

    //
    fun <T : Any> ioToFrag(work: suspend (() -> T?)) =
        CoroutineScope(Dispatchers.Main).launch {
            CoroutineScope(Dispatchers.IO).async wr@{
                return@wr work()
            }.await()
        }
}