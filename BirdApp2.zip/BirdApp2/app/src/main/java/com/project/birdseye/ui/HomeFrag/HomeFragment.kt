package com.project.birdseye.ui.HomeFrag

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.project.birdseye.adapters.BirdEyeAdapters
import com.project.birdseye.adapters.recyclerInterface
import com.project.birdseye.databinding.FragmentHomeBinding
import com.project.birdseye.ui.main.BirdDetail
import com.project.birdseye.util.DependencyInjection

class HomeFragment : Fragment(), recyclerInterface {

    private lateinit var binding: FragmentHomeBinding
    private lateinit var factory: HomeFragViewModelFactory
    private lateinit var viewModel: HomeFragViewModel
    private var birdAdapter: BirdEyeAdapters? = null

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.loadingLayout.visibility = View.VISIBLE
        //set up a viewModel and observer for it to dynamically populate after retrieval
        // Initialize the ViewModel
        factory = DependencyInjection.provideHomeFragViewModelFactory()
        viewModel = ViewModelProvider(this, factory)[HomeFragViewModel::class.java]
        // Set up the observer for viewModel.birds
        viewModel.birds.observe(this) { birds ->
            // Handle loading state
            if (birds == null) {
                // Handle loading state when the LiveData is null (initial state)
                binding.loadingLayout.visibility = View.VISIBLE
                binding.rvBirdsList.visibility = View.GONE
                binding.tvNoBirds.visibility = View.GONE
            } else if (birds.isEmpty()) {
                // Handle when there are no birds
                binding.loadingLayout.visibility = View.GONE
                binding.rvBirdsList.visibility = View.GONE
                binding.tvNoBirds.visibility = View.VISIBLE
            } else {
                // Handle when there are birds
                binding.loadingLayout.visibility = View.GONE
                binding.rvBirdsList.visibility = View.VISIBLE
                binding.tvNoBirds.visibility = View.GONE
                birdAdapter = BirdEyeAdapters(context!!, birds, this)
                binding.rvBirdsList.adapter = birdAdapter
                binding.rvBirdsList.layoutManager = LinearLayoutManager(context)
                binding.rvBirdsList.setHasFixedSize(false)
                binding.rvBirdsList.isNestedScrollingEnabled = false
                birdAdapter!!.notifyItemChanged(birds.size - 1)
            }
        }
        //Call getBirds to fetch the data
        viewModel.getBirds()
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onItemClick(pos: Int) {
        //navigate to next one
        val intent = Intent(context, BirdDetail::class.java)

        viewModel.birds.value!!.elementAt(pos).let { element ->
            intent.putExtra("title", element.title)
            intent.putExtra("img", element.image)
            intent.putExtra("desc", element.description)
            intent.putExtra("date", element.date)
            intent.putExtra("location", element.location)
            Log.i("LOCATION", "onItemClick: ${element.location}")
        }

        startActivity(intent)
    }
}