package com.project.birdseye.API

import retrofit2.Call
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Query

interface IBirdAPI {
    @GET ("geo")
    suspend fun getHotspots(
        @Query("lat") latitude: Double?,
        @Query("lng") longitude: Double?,
        @Query("dist") dist : Int?,
        @Query("fmt") format: String = "json"
    ) : Response<List<Birds>>?
}