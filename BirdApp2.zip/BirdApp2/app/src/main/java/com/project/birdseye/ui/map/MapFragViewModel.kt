package com.project.birdseye.ui.map

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.project.birdseye.model.BirdModel
import com.project.birdseye.util.FirebaseManager
import kotlinx.coroutines.Job
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.launch
import androidx.lifecycle.viewModelScope

class MapFragViewModel(private val mapRepo : MapFragRepo) : ViewModel() {
    private val _birds = MutableLiveData<List<BirdModel>?>()
    val birds : LiveData<List<BirdModel>?> = _birds
    private lateinit var job : Job

    init {
        // Initialize LiveData as null
        _birds.value = null
    }

    fun getBirds(){
        viewModelScope.launch{
            job = FirebaseManager.ioToFrag {
                mapRepo.getBirds { resultList ->
                    MainScope().launch {
                        _birds.value = resultList
                    }
                }
            }
        }
    }
}