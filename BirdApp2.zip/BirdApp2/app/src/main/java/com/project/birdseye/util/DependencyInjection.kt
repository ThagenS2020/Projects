package com.project.birdseye.util

import com.project.birdseye.mvvmArch.AuthRepo
import com.project.birdseye.mvvmArch.AuthViewModelFactory
import com.project.birdseye.ui.HomeFrag.HomeFragRepo
import com.project.birdseye.ui.HomeFrag.HomeFragViewModelFactory
import com.project.birdseye.ui.map.MapFragRepo
import com.project.birdseye.ui.map.MapFragViewModelFactory

object DependencyInjection {

    fun provideAuthViewModelFactory(): AuthViewModelFactory{
        return AuthViewModelFactory(authRepo = AuthRepo())
    }
    fun provideHomeFragViewModelFactory() : HomeFragViewModelFactory {
        return HomeFragViewModelFactory(homeFragRepo = HomeFragRepo())
    }

    fun provideMapFragViewModelFactory() : MapFragViewModelFactory {
        return MapFragViewModelFactory(mapFragRepo = MapFragRepo())
    }
}