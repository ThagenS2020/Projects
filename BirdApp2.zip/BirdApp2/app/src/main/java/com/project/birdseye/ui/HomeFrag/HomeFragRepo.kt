package com.project.birdseye.ui.HomeFrag

import android.util.Log
import com.google.firebase.database.*
import com.project.birdseye.model.BirdModel
import com.project.birdseye.util.FirebaseManager

class HomeFragRepo {
    private val database: FirebaseDatabase = FirebaseDatabase.getInstance()
    private val refUsers: DatabaseReference = database.getReference("users")
    private var list: MutableList<BirdModel> = mutableListOf()

    fun  getBirds(listCallback : (List<BirdModel>) -> Unit){
        var birdExists = false
        val birdRef =  refUsers.child(FirebaseManager.getCurrentUserID()).child("sightings")
        birdRef.addValueEventListener(object: ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if(snapshot.exists()) {
                    for (birdSnapshot in snapshot.children) {
                        val title = birdSnapshot.child("title").getValue(String::class.java)
                        val date = birdSnapshot.child("date").getValue(String::class.java)
                        val description =
                            birdSnapshot.child("description").getValue(String::class.java)
                        val id = birdSnapshot.child("id").getValue(String::class.java)
                        val image = birdSnapshot.child("image").getValue(String::class.java)
                        val location = birdSnapshot.child("location").getValue(String::class.java)
                        if (title != null && image != null) {
                            val bird = BirdModel(id, title, image, description, date, location)
                            for (i in list){
                                if ((title == i.title) && image == i.image ) {
                                    birdExists = true
                                }
                            }
                            if (!birdExists){
                                list.add(bird)
                            }
                        }
                    }
                }
                else if(list.isEmpty()){
                    list = mutableListOf()
                }
                Log.e("Main", "${list}")
                listCallback(list)
            }
            override fun onCancelled(databaseError: DatabaseError) {
                //TODO:Implement error handling
            }
        })
    }
}