package com.project.birdseye.ui.map

import android.util.Log
import com.google.firebase.database.*
import com.project.birdseye.model.BirdModel
import com.project.birdseye.util.FirebaseManager

class MapFragRepo {
    private val database: FirebaseDatabase = FirebaseDatabase.getInstance()
    private val refUsers: DatabaseReference = database.getReference("users")
    private var list: MutableList<BirdModel> = mutableListOf()

    fun getBirds(listCallback: (List<BirdModel>) -> Unit) {
        val birdRef = refUsers.child(FirebaseManager.getCurrentUserID()).child("sightings")
        birdRef.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (snapshot.exists()) {
                    for (birdSnapshot in snapshot.children) {
                        val title = birdSnapshot.child("title").getValue(String::class.java)
                        val location = birdSnapshot.child("location").getValue(String::class.java)
                        val bird = BirdModel(
                            id = null,
                            title = title,
                            image = null,
                            description = null,
                            date = null,
                            location = location
                        )
                        list.add(bird)
                    }
                }
                Log.e("Main", "${list}")
                listCallback(list)
            }

            override fun onCancelled(databaseError: DatabaseError) {
                //TODO:Implement error handling
            }
        })
    }
}