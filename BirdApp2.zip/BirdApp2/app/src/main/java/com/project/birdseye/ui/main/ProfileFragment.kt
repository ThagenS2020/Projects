package com.project.birdseye.ui.main

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.SeekBar
import android.widget.Toast
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.widget.doAfterTextChanged
import androidx.lifecycle.ViewModelProvider
import com.project.birdseye.API.Hotspots
import com.project.birdseye.databinding.FragmentProfileBinding
import com.project.birdseye.model.UserPreferences
import com.project.birdseye.mvvmArch.AuthViewModel
import com.project.birdseye.ui.login.LoginActivity
import com.project.birdseye.util.DependencyInjection
import com.project.birdseye.util.FirebaseManager
import com.project.birdseye.util.CurrentUser
import kotlinx.coroutines.runBlocking
import kotlin.math.round

class ProfileFragment : Fragment() {
    private lateinit var binding: FragmentProfileBinding
    private lateinit var viewModel: AuthViewModel
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentProfileBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel = ViewModelProvider(activity!!, factory = DependencyInjection.provideAuthViewModelFactory())[AuthViewModel::class.java]
        FirebaseManager.getPreferences { userPref, dbError ->
            if (userPref != null){
                binding.distanceValue.text = userPref.maxDistance.toString()
                binding.slider.progress = userPref.maxDistance
            }
            Log.i("error",dbError.toString())
        }

        val toggle = binding.toggle
        binding.logout.setOnClickListener {
            viewModel.logout()
            val intent = Intent(context, LoginActivity::class.java)
            activity!!.finish()
            this.startActivity(intent)
            return@setOnClickListener
        }

        binding.distanceValue.doAfterTextChanged {
            binding.btnSave.isEnabled = true
        }

        binding.btnSave.setOnClickListener {
            val res = convertSeekBarProgressToDistance()
            val measurement = UserPreferences()
            if (toggle.text == "Metric")
                measurement.measurementSystem = "Metric"
            else
                measurement.measurementSystem = "Imperial"

            measurement.maxDistance = res
            //update preferences
            runBlocking {
                FirebaseManager.savePreferences(measurement){
                    Log.i("complete", "FINISHED")
                    return@savePreferences
                }
            }
            //get new sightings based on preferences
            CurrentUser.location.observe(this){ current ->
                FirebaseManager.getPreferences { userPref, dbError ->
                    Hotspots.getHotspots(CurrentUser.toLatLng(current),userPref!!)
                }
            }

            Toast.makeText(
                context,
                "${res} and the measurement system is ${measurement.measurementSystem}",
                Toast.LENGTH_LONG
            ).show()
        }

        // FOR SLIDER
        val slider = binding.slider
        slider.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                binding.distanceValue.setText(progress.toString())
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {

            }

            override fun onStopTrackingTouch(seekBar: SeekBar?) {

            }
        })

    }

    fun convertSeekBarProgressToDistance(): Int {
        // DISTANCE CONVERTER
        val sliderDistance = binding.slider
        val toggle = binding.toggle
        val progress = sliderDistance.progress
        val isMlSelected = toggle.isChecked

        val conversionFactor = if (!isMlSelected) {
            1.0
        } else {
            1.60934
        }
        //needs the ten for any number greater than ten
        val distance = (progress) * conversionFactor

        return round(distance).toInt()
    }
}