package com.project.birdseye.model

//default is set to metric and 2km
data class UserPreferences(var measurementSystem : String = "Metric", var maxDistance : Int = 10)